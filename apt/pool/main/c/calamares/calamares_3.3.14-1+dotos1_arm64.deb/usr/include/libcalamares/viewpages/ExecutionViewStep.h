/* === This file is part of Calamares - <https://calamares.io> ===
 *
 *   SPDX-FileCopyrightText: 2014 Aurélien Gâteau <agateau@kde.org>
 *   SPDX-FileCopyrightText: 2014-2015 Teo Mrnjavac <teo@kde.org>
 *   SPDX-License-Identifier: GPL-3.0-or-later
 *
 *   Calamares is Free Software: see the License-Identifier above.
 *
 */

#ifndef EXECUTIONVIEWSTEP_H
#define EXECUTIONVIEWSTEP_H

#include "ViewStep.h"
#include "modulesystem/InstanceKey.h"
#include "widgets/LogWidget.h"

#include <QStringList>

class QLabel;
class QObject;
class QProgressBar;
class QTabWidget;

namespace Calamares
{

class Slideshow;

/**
 * @brief Install progress for QML (DOT OS)
 *
 * Registered as the singleton "Execution" in io.calamares.ui, so the
 * slideshow and the navigation panel can draw the install step themselves:
 * the progress (0..1), the current status message, whether the log is
 * showing, and a way to show or hide it.
 */
class UIDLLEXPORT ExecutionState : public QObject
{
    Q_OBJECT
    Q_PROPERTY( qreal progress READ progress NOTIFY progressChanged FINAL )
    Q_PROPERTY( QString message READ message NOTIFY progressChanged FINAL )
    Q_PROPERTY( bool active READ active NOTIFY activeChanged FINAL )
    Q_PROPERTY( bool logVisible READ logVisible NOTIFY logVisibleChanged FINAL )

public:
    static ExecutionState* instance();

    qreal progress() const { return m_progress; }
    QString message() const { return m_message; }
    bool active() const { return m_active; }
    bool logVisible() const { return m_logVisible; }

    void setProgress( qreal progress, const QString& message );
    void setActive( bool active );
    void setLogVisible( bool visible );

    /// Ask the install step to show or hide its log.
    Q_INVOKABLE void toggleLog();

signals:
    void progressChanged();
    void activeChanged();
    void logVisibleChanged();
    void toggleLogRequested();

private:
    explicit ExecutionState( QObject* parent = nullptr );

    qreal m_progress = 0;
    QString m_message;
    bool m_active = false;
    bool m_logVisible = false;
};

/**
 * @class
 *
 * This is the implementation of the special ViewStep "Install"
 * which takes care of an *exec* phase in the sequence. It runs
 * jobs, shows the slideshow, etc.
 */
class UIDLLEXPORT ExecutionViewStep : public ViewStep
{
    Q_OBJECT
public:
    explicit ExecutionViewStep( QObject* parent = nullptr );

    QString prettyName() const override;

    QWidget* widget() override;

    void next() override;
    void back() override;

    bool isNextEnabled() const override;
    bool isBackEnabled() const override;

    bool isAtBeginning() const override;
    bool isAtEnd() const override;

    void onActivate() override;
    void onLeave() override;

    JobList jobs() const override;

    void appendJobModuleInstanceKey( const ModuleSystem::InstanceKey& instanceKey );

private:
    QWidget* m_widget;
    QProgressBar* m_progressBar;
    QLabel* m_label;
    Slideshow* m_slideshow;
    QTabWidget* m_tab_widget;
    LogWidget* m_log_widget;

    QList< ModuleSystem::InstanceKey > m_jobInstanceKeys;

    void updateFromJobQueue( qreal percent, const QString& message );

    void toggleLog();
};

}  // namespace Calamares

#endif /* EXECUTIONVIEWSTEP_H */
