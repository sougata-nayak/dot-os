// Design tokens for the installer. build.py fills the token markers from
// design-system/tokens.json (dark theme), so these never drift.
pragma Singleton
import QtQuick

QtObject {
    readonly property color black: "#000000"
    readonly property color surface: "#111111"
    readonly property color surfaceRaised: "#1A1A1A"
    readonly property color border: "#222222"
    readonly property color borderVisible: "#333333"
    readonly property color textDisabled: "#666666"
    readonly property color textSecondary: "#999999"
    readonly property color textPrimary: "#E8E8E8"
    readonly property color textDisplay: "#FFFFFF"
    readonly property color accent: "#D71921"
    readonly property color success: "#4A9E5C"
    readonly property color warning: "#D4A843"

    readonly property string mono: "Space Mono"
    readonly property string sans: "Space Grotesk"
    readonly property string display: "Doto"

    readonly property int controlMin: 44
    readonly property int radiusTechnical: 4
    readonly property int radiusCompact: 8

    // Page layout from design-system/boards/Install*.dc.html.
    readonly property int padX: 48
    readonly property int padY: 32
    readonly property int colLeft: 440
    readonly property int colGap: 64

    readonly property string version: "0.1.0"

    // Step names as the boards print them; Calamares' own names otherwise.
    function stepName(name) {
        var map = { "Partitions": "Disk", "Users": "User" };
        return map[name] !== undefined ? map[name] : name;
    }
    // Button labels arrive with mnemonics ("&Next").
    function plain(label) { return label.replace(/&(?!&)/g, ""); }
}
